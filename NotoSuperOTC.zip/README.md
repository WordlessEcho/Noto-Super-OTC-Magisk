# Noto CJK Fonts Installer (Super OTC)
This is a module add more font weight for CJK(Chinese, Japanese and Korean) by modify the `fonts.xml`.
By putting the charater to a single file, it reduce some space compare to install fonts for each languages.
That is super OTC font.

# Installation
You need at least Android 7(Nougat) to use super OTC.
- Download [NotoSansCJK.ttc.zip](https://noto-website-2.storage.googleapis.com/pkgs/NotoSansCJK.ttc.zip).
- For **Android 9(Pie) or above**, download both of [NotoSansCJK.ttc.zip](https://noto-website-2.storage.googleapis.com/pkgs/NotoSansCJK.ttc.zip) 
and [NotoSerifCJK.ttc.zip](https://noto-website-2.storage.googleapis.com/pkgs/NotoSerifCJK.ttc.zip).
- Unzip the `.ttc` font files to `/sdcard/Download/`.
- Go [releases](https://github.com/WordlessEcho/Noto-Super-OTC-Installer/releases) to download this module and install in Magisk.

Enjoy! Pay attation to app title bar, drawer and Wikipedia(for Android 9+).
